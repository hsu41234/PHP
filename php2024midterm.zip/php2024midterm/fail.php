<meta charset="utf-8">

<?php

echo "登入失敗<br/>";
echo "5秒鐘之後重試一次";
header("Refresh:5;url=logout.php");

?>