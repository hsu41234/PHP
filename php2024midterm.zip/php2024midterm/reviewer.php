<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<h2>reviewer您好 歡迎進入論文評論網頁</h2>
</head>

<?php

	if(isset($_POST['logout_btn']))
	{
		header("Location: logout.php");

	}
    if(isset($_POST['Submit']))
    {
        header("Location: showreview.php");
    }
?>
<body>
<form action="showreview.php" method="post"> 
    論文委員決定：
    <input type="radio" name="sDecide" value="accept">Accept
    <input type="radio" name="sDecide" value="minorrevision">Minor Revision
    <input type="radio" name="sDecide" value="majorrevision">Major Revision
    <input type="radio" name="sDecide" value="reject">Reject
</br>
論文評論評語：
<textarea name="sComment" value="" rows="10" cols="50">
</textarea>
</br>
<form method="post"> 
    <button type="submit" name="Submit">提交
    <button type="submit" name="logout_btn">登出

</form>
</body>
<html>