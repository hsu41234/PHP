<?php
ob_start();
session_start();

$credentials = [
    "chair" => "123",
    "reviewer" => "234",
    "author" => "345"
];

$uId = $_GET["uId"] ?? "";
$uPwd = $_GET["uPwd"] ?? "";

if (isset($credentials[$uId]) && $credentials[$uId] == $uPwd) {
    $_SESSION["check"] = "Yes";
    header("Location: " . $uId . ".php");
} else {
    $_SESSION["check"] = "No";
    header("Location: fail.php");
}
ob_flush();
?>