<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
</head>
<?php
?>
<body>
<h2>高大資管論文投稿系統</h2>
<form action="check.php" method="get">
請選擇你的角色：
<select  name=”Role:>
    <option value=”chair”> chair </option>
    <option value=”reviewer”> reviewer </option>
    <option value=”author”> author </option>

</select><br/>
帳號:<input type="text" name="uId"><br/>
密碼:<input type="password" name="uPwd"><br/>
<input type="submit">
</form>
</body>
</html>