<html>
<head>
<meta charset="utf-8">
</head>
<?php
    

	if(isset($_POST['logout_btn']))
	{
		header("Location: logout.php");
	}
?>
<body>
<form method="post"> 
	<button type="submit" name="logout_btn">登出
	</button>
</form>
</body>
</html>