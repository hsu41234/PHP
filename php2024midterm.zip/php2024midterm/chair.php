<meta charset="utf-8">



<?php

echo "歡迎來到chair<br/>";

if(isset($_POST['logout_btn']))
	{
		header("Location: logout.php");

	}
?>
<form method="post"> 
	<button type="submit" name="logout_btn">登出
	</button>
</form>