<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<h2>author您好 歡迎進入論文投稿網頁</h2>
</head>

<?php

if(isset($_POST['logout_btn']))
	{
		header("Location: logout.php");

	}
    if(isset($_POST['Submit']))
    {
        header("Location: showpaper.php");
    }
?>
<body>
<form action="showpaper.php" method="post"> 
論文標題：<input type="title" name=sTitle><br/>
作者姓名:<input type="text" name="sName" placeholder="Please input your name"><br/>
作者email:<input type="email" name=sEmail><br/>
</br>
論文摘要：
<textarea name="sComment" value="" rows="10" cols="50">
</textarea>
</br>
<form method="post"> 
    <button type="submit" name="Submit">提交
    <button type="submit" name="logout_btn">登出

</form>
</body>
<html>